I only have the redirection from the files (<, >).  Sorry, I just underestimated this assignment. Worked for about 10 hours just on filters and couldn't get it to work.

To run:
make clean
make
./cs350sh
