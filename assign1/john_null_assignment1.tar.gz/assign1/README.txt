To run:
make clean
make
./cs350sh

May or may not work on LDAP. Works fine on my computer, except typing commands while a process is in the foreground causes the commands to execute after the foreground process has finished.
Sorry everything is in the main. I realize this is bad practice. I started out by testing some things in the main, then I just ran with what I had and that was the result.
