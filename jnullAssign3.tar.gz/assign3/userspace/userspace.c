#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
int main(){
	int fd, bufL;
	char *buf = malloc(sizeof(char) * 10000);
	if(!buf) return -1;
	if((fd = open("/dev/hello", O_RDONLY)) < 0){
		return -1;
	}
	int bytes_read = read(fd, buf, bufL);
	printf("%s", buf);
	close(fd);
	free(buf);
	return 0;
}
