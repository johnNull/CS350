Sometimes, it fills in a small amount of junk in the beginning so it also cuts off the last part of the state at the end. Sometimes it also frees before it can print.

to run:
	in assign3 directory:
	make
	sudo insmod assign3.ko
	
	in userspace directory:
	make
	sudo ./userspace
