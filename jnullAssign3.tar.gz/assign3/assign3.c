/*
 * "Hello, world!" kernel module - /dev version
 */

#include <linux/fs.h>
#include <linux/init.h>
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/slab.h>

#include <asm/uaccess.h>

static ssize_t hello_read(struct file * file, char * buf, 
			  size_t count, loff_t *ppos)
{
	char **pInfo, *final = NULL;
	int len = 0, pCount = 0, stateCount = 0, counter = 0;
	struct task_struct *p;
	for_each_process(p){
		pCount++;
	}
	printk(KERN_INFO"%d a", pCount);
	pInfo = kmalloc(pCount*sizeof(char*), GFP_KERNEL);
	if(!pInfo) printk(KERN_ERR);
	pCount = 0;
	for_each_process(p){
		char *state = kmalloc(0,GFP_KERNEL);
		if(!state) printk(KERN_ERR);
		if(p->state == 0) state = "TASK_RUNNING";
		if(p->state == 1) state = "TASK_INTERRUPTIBLE";
		if(p->state == 2) state = "TASK_UNINTERRUPTIBLE";
		if(p->state == 4) state = "TASK_STOPPED";
		if(p->state == 8) state = "TASK_TRACED";
		if(p->state == 16) state = "EXIT_DEAD";
		if(p->state == 32) state = "EXIT_ZOMBIE";
		if(p->state == 64) state = "TASK_DEAD";
		if(p->state == 128) state = "TASK_WAKEKILL";
		if(p->state == 256) state = "TASK_WAKING";
		if(p->state == 512) state = "TASK_PARKED";
		if(p->state == 1024) state = "TASK_NOLOAD";
		if(p->state == 2048) state = "TASK_NEW";
		if(p->state == 4096) state = "TASK_STATE_MAX";
		
		stateCount = strlen(state);
		pInfo[pCount] = kmalloc((43 + stateCount) * sizeof(char), GFP_KERNEL);
		len += snprintf(pInfo[pCount], 43 + stateCount, "PID : %d, PPID: %d, CPU: %d, State: %s\n", p->pid, p->parent->pid, task_cpu(p), state);
		pCount++;
	}
	//printk(KERN_INFO"%d\n", pCount);
	final = kmalloc(len, GFP_KERNEL);
	if(!final) printk(KERN_ERR);
	for(counter = 0; counter < pCount; counter++){
		strcat(final,pInfo[counter]);
	}
	/*
	 * We only support reading the whole string at once.
	 */
	if (count < len)
		return -EINVAL;
	/*
	 * If file position is non-zero, then assume the string has
	 * been read and indicate there is no more data to be read.
	 */
	if (*ppos != 0)
		return 0;
	/*
	 * Besides copying the string to the user provided buffer,
	 * this function also checks that the user has permission to
	 * write to the buffer, that it is mapped, etc.
	 */
	if (copy_to_user(buf, final, len))
		return -EINVAL;
	/*
	 * Tell the user how much data we wrote.
	 */
	*ppos = len;
	for(counter = 0; counter < pCount; counter++){
		kfree(pInfo[counter]);
	}
	kfree(pInfo);
	kfree(final);
	return len;
}

/*
 * The only file operation we care about is read.
 */

static const struct file_operations hello_fops = {
	.owner		= THIS_MODULE,
	.read		= hello_read,
};

static struct miscdevice hello_dev = {
	/*
	 * We don't care what minor number we end up with, so tell the
	 * kernel to just pick one.
	 */
	MISC_DYNAMIC_MINOR,
	/*
	 * Name ourselves /dev/hello.
	 */
	"hello",
	/*
	 * What functions to call when a program performs file
	 * operations on the device.
	 */
	&hello_fops
};

static int __init
hello_init(void)
{
	int ret;

	/*
	 * Create the "hello" device in the /sys/class/misc directory.
	 * Udev will automatically create the /dev/hello device using
	 * the default rules.
	 */
	ret = misc_register(&hello_dev);
	if (ret)
		printk(KERN_ERR
		       "Unable to register \"Hello, world!\" misc device\n");

	return ret;
}

module_init(hello_init);

static void __exit
hello_exit(void)
{
	misc_deregister(&hello_dev);
}

module_exit(hello_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("John Null");
MODULE_DESCRIPTION("\"Process_list\" kernel module");
MODULE_VERSION("dev");
